<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class InfoWidget extends Widget
{
    protected static string $view = 'filament.widgets.info-widget';

    protected int | string | array $columnSpan = 'full';
}
